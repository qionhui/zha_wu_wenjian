<?php

$abc="";

if ( isset( $_POST['usr']) )
{
	  $usr=$_POST['usr'];
	  $pwd=$_POST['pwd'];  
	  $repwd=$_POST['repwd']; 
	  if ($pwd=="")
	  {
		  $abc= '<script>alert("密码不为空");</script>';
	  }
	  else if ($pwd!=$repwd)
	  {
	      $abc= '<script>alert("密码不一致");</script>';
	  }
	  else
	  {
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "lym";
			 
			// 创建连接
			$conn = new mysqli($servername, $username, $password, $dbname);
			 
			$sql = "INSERT INTO user (username, pwd)
			VALUES ('".$usr."', '".$pwd."')";
			 
			if ($conn->query($sql) === TRUE) {
				$abc= '<script>alert("cg");</script>';
			} else {
				$abc= '<script>alert("sb");</script>';
			}
			 
			$conn->close();
	  }
	   
}


?>


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>无标题文档</title>
</head>

<body>
<form name="form1" method="post" action="">
  <p>用户名：
    <input type="text" name="usr" id="usr">
  </p>
  <p>密码：
    <input type="text" name="pwd" id="pwd">
  </p>
  <p>确认密码：
    <input type="text" name="repwd" id="repwd">
  </p>
  <p>
    <input type="submit" name="button" id="button" value="注册">
  </p>
</form>
<?php echo $abc ?>
</body>
</html>
