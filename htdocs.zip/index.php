﻿<?php
   session_start();
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lym";
	 
	// 创建连接
	$conn = new mysqli($servername, $username, $password, $dbname);
	
   if (isset($_COOKIE['usr'])) $_SESSION['usr']=$_COOKIE['usr'];
   
   
   if ( isset( $_POST['usr']) )
   {
	
	  $usr=$_POST['usr'];
	  $pwd=$_POST['pwd'];
	  

	$sql = "SELECT count(*) as abc FROM user where username='". $usr ."' and pwd='". $pwd ."'";
	$result = $conn->query($sql);
	$row = $result->fetch_assoc();
	if ($row['abc']==1) 
	{
		  $_SESSION['usr']=$usr;
		  setcookie("usr", $usr, time()+3600);
	 }
	 else echo'<script>alert("hello");</script>';
	
   }
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome Halloween Personal Blog</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<table width="896" border="0" align="center" cellpadding="0" cellspacing="0">
 <!--body Panel Start-->
  <tr>
    <td align="left" valign="top">
		<table width="896" border="0" cellspacing="0" cellpadding="0">
		  <tr>
		  <!--body left Panel Start-->
			<td width="217" align="left" valign="top">
				<table width="217" border="0" cellspacing="0" cellpadding="0">
				  <tr>
					<td align="left" valign="top" class="logoPadding"><img src="images/logo.jpg" alt=" Halloween Personal Blog" width="217" height="117" border="0" title=" Halloween Personal Blog" /></td>
				  </tr>
				  <tr>
					<td align="left" valign="top" class="quickSearchPadding">
						<form name="Search" action="" method="get">
							<table width="217" border="0" cellspacing="0" cellpadding="0">
						  <tr>
							<td align="left" valign="top" class="quickSearch">Quick Search</td>
						  </tr>
						  <tr>
							<td align="left" valign="top">
								<table width="217" border="0" cellspacing="0" cellpadding="0">
								  <tr>
									<td width="193" height="28" align="left" valign="bottom"><input name="" type="text" class="textBox" /></td>
									<td width="24" height="28" align="left" valign="bottom"><input name="" type="image" src="images/goButton.gif" title="go" /></td>
								  </tr>
							  </table>							</td>
						  </tr>
						</table>
						</form>					</td>
				  </tr>
				  <tr>
					<td align="left" valign="top">
						<table width="217" border="0" cellspacing="0" cellpadding="0">
						  <tr>
							<td align="left" valign="top" class="archive">Archive</td>
						  </tr>
						  <tr>
							<td align="left" valign="top">
								<ul class="archiv">
									<li><span><a href="#">Ullamcorper tempus odio sed vitae urna.</a></span></li>
									<li><span><a href="#">Nunc elit nam ut neque id sem adipiscing </a></span></li>
									<li><span><a href="#">Pretium vestibulum facilisis euismod justo </a></span></li>
									<li><span><a href="#">Maecenas gravida facilisis dui vivamus </a></span></li>
									<li><span><a href="#">lFctus blandit neque fusce rutrum turpis </a></span></li>
									<li class="noBrownDot"><span><a href="#">Dvelit pellentesque commodo vivamus</a></span></li>
								</ul>							</td>
						  </tr>
						</table>					</td>
				  </tr>
				  <tr>
					<td align="left" valign="top" class="newsPanelPadding">
						<table width="217" border="0" cellspacing="0" cellpadding="0">
						  <tr>
							<td align="left" valign="top" class="news">News &amp; Events</td>
						  </tr>
						  <tr>
							<td align="left" valign="top" class="newsTxtPanelPadding">
							  <table width="217" border="0" cellspacing="0" cellpadding="0">
								  <tr>
									<td width="57" align="left" valign="top"><img src="images/Date1.gif" alt="Date1" width="47" height="49" title="Date1" /></td>
									<td width="160" align="left" valign="top" class="newsTxt">Morbi non dolor at nunc ultricees bibendum. Suspendisse fermen tum lacul.............................<a href="#" title="more">more</a></td>
								  </tr>
							  </table>							</td>
						  </tr>
						  <tr>
							<td align="left" valign="top" class="newsTxtPanelPadding2">
								<table width="217" border="0" cellspacing="0" cellpadding="0">
								  <tr>
									<td width="57" align="left" valign="top"><img src="images/Date2.gif" alt="Date2" width="47" height="49" title="Date2" /></td>
									<td width="160" align="left" valign="top" class="newsTxt">Morbi non dolor at nunc ultricees bibendum. Suspendisse fermen tum lacul.............................<a href="#" title="more">more</a></td>
								  </tr>
								</table>							</td>
						  </tr>
					  </table>					</td>
				  </tr>
				  <tr>
					<td align="left" valign="top">
						<table width="217" border="0" cellspacing="0" cellpadding="0">
						  <tr>
							<td align="left" valign="top" class="links">Links</td>
						  </tr>
						  <tr>
							<td align="left" valign="top">
								<ul class="linkYellow">
									<li><span><a href="#">Fusce dictum pulvinar dolorIn for rutrum </a></span></li>
									<li><span><a href="#">Nunc at interdum varius diam risus </a></span></li>
									<li><span><a href="#">Ullamcorpe libero hendrerit rhoncusquam </a></span></li>
									<li><span><a href="#">Mi sed dui duis felis justo congue quis </a></span></li>
									<li class="noBrownDot"><span><a href="#">Borta eu congue vel odio nulla facilisi </a></span></li>
								</ul>							</td>
						  </tr>
					  </table>					</td>
				  </tr>
				</table>			</td>
			<!--body left Panel End-->
			<td width="20" align="left" valign="top">&nbsp;</td>
			<!--body Middle Panel Start-->
			<td width="422" align="left" valign="top" class="middleBodyPadding">
				<table width="422" border="0" cellspacing="0" cellpadding="0">
				  <tr>
					<td align="left" valign="top">
						<table width="422" border="0" cellspacing="0" cellpadding="0">
						  <tr>
							<td width="9" align="left" valign="top" class="topnavLeftRoundBG">&nbsp;</td>
							<td width="404" align="left" valign="top" class="topnavRepeatBG">
								<ul class="topnav">
									<li><a href="#" title="Home" class="active">Home</a></li>
									<li><a href="#" title="About Me">About Me</a></li>
									<li><a href="#" title="Blog">Blog</a></li>
									<li><a href="#" title="Gallery">Gallery</a></li>
									<li class="notopodiv"><a href="#" title="Contact Me">Contact Me</a></li>
								</ul>							</td>
							<td width="9" align="left" valign="top" class="topnavRightRoundBG">&nbsp;</td>
						  </tr>
					  </table>					</td>
				  </tr>
				  <tr>
					<td align="left" valign="top">
						<table width="422" border="0" cellspacing="0" cellpadding="0">
						  <tr>
							<td align="left" valign="top" class="welcomeTopBg">&nbsp;</td>
						  </tr>
						  <tr>
							<td align="left" valign="top" class="welcomeBg">
								<table width="384" border="0" align="center" cellpadding="0" cellspacing="0">
								  <tr>
									<td align="left" valign="top" class="welcome">Welcome to My Site</td>
								  </tr>
								  <tr>
									<td align="left" valign="top">
										<table width="384" border="0" cellspacing="0" cellpadding="0">
										  <tr>
											<td align="left" valign="top" class="welcomeTxt">Fusce ullamcorper tempus odio sed vitae urna.</td>
										  </tr>
										  <tr>
											<td align="left" valign="top" class="welcomeSmallTxt">Nullam fringilla vestibulum sem deonec auctor placerat felis. Etiam eget diam for nullam eleifend. Vivamus arcu nulla rutrum eu malesuada vel euismod at sem. Suspendisse potenti nunc dapibus risus eu enim. Nullam dui. Donec sollicitudin tortor vel turp malesuada vel euismod.</td>
										  </tr>
										  <tr>
											<td align="left" valign="top"><p class="welmore"><a href="#" title="more">more</a></p></td>
										  </tr>
									  </table>									</td>
								  </tr>
								  <tr>
									<td align="left" valign="top" class="festivals">Festivals</td>
								  </tr>
								  <tr>
									<td align="left" valign="top" class="festivalsImgBG">
										<table width="354" border="0" align="center" cellpadding="0" cellspacing="0">
										  <tr>
                                          
<?php
$sql = "SELECT * FROM news  order by nid desc limit 3";
$result = $conn->query($sql);
 
if ($result->num_rows > 0) {
    // 输出数据
    while($row = $result->fetch_assoc()) {
?>   
<td width="122" align="left" valign="top"><a href="#"><img src="images/<?php echo $row['tp'] ?>" alt="Festival1" width="108" height="85" border="0" title="Festival1" class="festivalsImg" /></a></td>
   
<?php   
    }
} else {
    echo "0 结果";
}
$conn->close();
?>
                                          
											
											
										  </tr>
									  </table>									</td>
								  </tr>
								  <tr>
									<td align="left" valign="top">
										<table width="384" border="0" cellspacing="0" cellpadding="0">
										  <tr>
											<td align="left" valign="top" class="festivalsTxt">Fusce dictum pulvinar dolor in rutrumf nunc at interdum varius diam </td>
										  </tr>
										  <tr>
											<td align="left" valign="top" class="welcomeSmallTxt">Risus ullamcorper libero hendrerit rhoncus quam mi sed dui. Duis felis justo foer congue quis porta eu congue vel odio. Nulla facilisi nullam gravida arcu of eget odio sed tempus. Nullam fringilla vestibulum sem.</td>
										  </tr>
										  <tr>
											<td align="left" valign="top"><p class="welmore"><a href="#" title="more">more</a></p></td>
										  </tr>
										</table>									</td>
								  </tr>
							  </table>							</td>
						  </tr>
					  </table>					</td>
				  </tr>
			  </table>			</td>
			<!--body Middle Panel End-->
			<td width="19" align="left" valign="top">&nbsp;</td>
			<!--body Right Panel Start-->
			<td width="218" align="left" valign="top" class="bodyrightPanelPadding"><table width="218" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td align="left" valign="top" class="memberloginPadding"><form action="" method="post" name="login" id="login">
                <?php  if(!isset( $_SESSION['usr'] )) {?>
                    <table width="218" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td align="left" valign="top" class="memberlogin">Member Login</td>
                      </tr>
                      <tr>
                        <td height="45" align="left" valign="bottom"><input name="usr" type="text" class="membertextBox" value="- user name -" /></td>
                      </tr>
                      <tr>
                        <td height="30" align="left" valign="bottom"><input name="pwd" type="password" class="membertextBox" value="******" /></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><table width="218" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                              <td width="166" height="32" align="left" valign="bottom" class="forgetPassword"><a href="#" title="Forgot Password">Forgot Password ?</a></td>
                              <td width="52" height="32" align="left" valign="bottom"><input name="Input" type="image" src="images/login.gif" title="login" /></td>
                            </tr>
                        </table></td>
                      </tr>
                    </table>
                    <?php } 
						else
						{
						    echo '???,'.$_SESSION['usr'];	
						}
					?>
                </form></td>
              </tr>
              <tr>
                <td align="left" valign="top">
				<table width="218" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td align="left" valign="top" class="meta">Meta</td>
                    </tr>
                    <tr>
                      <td align="left" valign="top"><ul class="archiv">
                          <li><span><a href="#">Fusce dictum pulvinar dolorIn for rutrum </a></span></li>
                        <li><span><a href="#">Nunc at interdum varius diam risus </a></span></li>
                        <li><span><a href="#">Ullamcorpe libero hendrerit rhoncusquam </a></span></li>
                        <li><span><a href="#">Mi sed dui duis felis justo congue quis </a></span></li>
                        <li class="noBrownDot"><span><a href="#">Borta eu congue vel odio nulla facilisi </a></span></li>
                      </ul></td>
                    </tr>
                </table></td>
              </tr>
              <tr>
                <td align="left" valign="top"><table width="218" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td align="left" valign="top" class="works">Works</td>
                    </tr>
                    <tr>
                      <td align="left" valign="top" class="bannerPadding"><a href="#"><img src="images/banner.jpg" alt="banner" width="218" height="80" border="0" title="banner" /></a></td>
                    </tr>
                    <tr>
                      <td align="left" valign="top"><ul class="workslink">
                          <li><span><a href="#">Ullamcorper tempus odio sed vitae urna.</a></span></li>
                        <li><span><a href="#">Nunc elit nam ut neque id sem adipiscing </a></span></li>
                        <li><span><a href="#">Pretium vestibulum facilisis euismod justo </a></span></li>
                        <li><span><a href="#">Maecenas gravida facilisis dui vivamus </a></span></li>
                        <li><span><a href="#">lFctus blandit neque fusce rutrum turpis </a></span></li>
                        <li class="noBrownDot"><span><a href="#">Dvelit pellentesque commodo vivamus</a></span></li>
                      </ul></td>
                    </tr>
                </table></td>
              </tr>
            </table></td>
			<!--body Right Panel End-->
		  </tr>
		</table>
	</td>
  </tr>
  <!--body Panel End-->
  <!--Footer Panel Start-->
  <tr>
    <td align="left" valign="top" class="footerPadding"><table width="896" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="left" valign="top"><ul class="footernav">
            <li><a href="#" title="Home">Home</a></li>
          <li><a href="#" title="About Me">About Me</a></li>
          <li><a href="#" title="Blog">Blog</a></li>
          <li><a href="#" title="Gallery">Gallery</a></li>
          <li><a href="#" title="Works">Works</a></li>
          <li><a href="#" title="Interest">Interest</a></li>
          <li class="nofooterDiv"><a href="#" title="Contact Me">Contact Me</a></li>
        </ul></td>
      </tr>
      <tr>
        <td align="center" valign="top"><p class="copyright">&copy; Copyright Information Goes Here. All Rights Reserved.<span>Design by: <a href="http://www.templatekingdom.com" target="_blank" title="Template Kingdom.com">Template Kingdom.com</a></span></p></td>
      </tr>
    </table></td>
  </tr>
  <!--Footer Panel End-->
</table>

</body>
</html>
