<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lym";
 
// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
$sql = "delete FROM news where nid=".$_GET['id'];
$result = $conn->query($sql);
$conn->close();

header("location:lb.php");

?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>无标题文档</title>
</head>

<body>
</body>
</html>
