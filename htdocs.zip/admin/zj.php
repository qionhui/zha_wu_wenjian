<?php

$abc="";

if ( isset( $_POST['bt']) )
{
	  $bt=$_POST['bt'];
	  $nr=$_POST['nr'];  
	  $tp=$_POST['tp']; 

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lym";
     
    // 创建连接
    $conn = new mysqli($servername, $username, $password, $dbname);
     
    $sql = "INSERT INTO news (bt, nr, tp)
    VALUES ('".$bt."', '".$nr."','".$tp."')";
     
    if ($conn->query($sql) === TRUE) {
        $abc= '<script>alert("cg");</script>';
    } else {
        $abc= '<script>alert("sb");</script>';
    }
     
    $conn->close();

	   
}


?>


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>无标题文档</title>
</head>

<body>
<form name="form1" method="post" action="">
  <p>标题：
    <input type="text" name="bt" id="bt">
  </p>
  <p>内容&nbsp;：
    <textarea name="nr" id="nr"></textarea>
  </p>
  <p>图片：
    <input type="text" name="tp" id="tp">
  </p>
  <p>
    <input type="submit" name="button" id="button" value="注册">
  </p>
</form>
<?php echo $abc ?>
</body>
</html>
