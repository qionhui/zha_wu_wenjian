<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<p><a href="zj.php">发布新闻</a></p>
<table width="800" border="1">
  <tr>
    <td align="center">图片</td>
    <td align="center">标题</td>
    <td align="center">操作</td>
  </tr>
  
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lym";
 
// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
$sql = "SELECT * FROM news";
$result = $conn->query($sql);
 
if ($result->num_rows > 0) {
    // 输出数据
    while($row = $result->fetch_assoc()) {
?>   
  <tr>
    <td><img src='../images/<?php echo $row['tp'] ?>' width='150' /></td>
    <td><?php echo $row['bt'] ?></td>
    <td><a href='xg.php?id=<?php echo $row['nid'] ?>'>修改</a>  <a href='sc.php?id=<?php echo $row['nid'] ?>'>删除</a></td>
  </tr>   
   
<?php   
    }
} else {
    echo "0 结果";
}
$conn->close();
?>


  
  
  
</table>
</body>
</html>
