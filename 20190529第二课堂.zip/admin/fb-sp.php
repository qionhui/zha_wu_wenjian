<?php include "cn.php" ?>



<!DOCTYPE html>
<html>

	<head>
		<meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" />
		<meta name="format-detection" content="telephone=no, email=no, date=no, address=no">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="format-detection" content="telephone=no" />
		<meta name="apple-mobile-web-app-capable" content="yes" />
		<meta content="black" name="apple-mobile-web-app-status-bar-style">
		<link href="css/bksystem.css" rel="stylesheet" type="text/css" />
		<link href="font/iconfont.css" rel="stylesheet" type="text/css" />
		<link href="css/module.css" rel="stylesheet" type="text/css" />
		<link href="css/pages.css" rel="stylesheet" type="text/css" />
		<title>系统设置</title>
		<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script>
		<script src="js/jquery.cookie.js" type="text/javascript"></script>
		<script src="js/jquery.nicescroll.js" type="text/javascript"></script>
		<script src="js/HUpages.js" type="text/javascript"></script>
	</head>

	<body id="pagestyle" class="padding15">
		<div class="Bombbox-info Tab-Module">
		  <ul class="tab_memu box">
				<li class="boxbox-flex2">
					<a href="javascript:void(0)" class="memu_title btn btn-border clickBombbox selected" data-id="0">基本设置</a>
				</li>
			</ul>
            <form method="post" enctype="multipart/form-data" name="frm" id="frm" >
			<div class="tab-box tabcontent">
				<div class="tab-conent prompt_style active">
					<ul class="clearfix add_style">
					    <li class="cell-item">
						   <label class="cell-left label_name">商品标题:</label>
						   <div class="cell-right"><input name="bt" type="text" class="col-xs-6 col-lg-12" id="bt"></div>  
					    </li>
					     <li class="cell-item">
						   <label class="cell-left label_name">图片路径:</label>
						   <div class="cell-right"><input name="tp" type="file" class="col-xs-6 col-lg-12" id="tp"></div>  
					    </li>
					    <li class="cell-item">
						   <label class="cell-left label_name">商品价格:</label>
						   <div class="cell-right"><input name="jg" type="text" class="col-xs-6 col-lg-12" id="jg"></div>  
					    </li>
					    <li class="cell-item">
						   <label class="cell-left label_name">商品详情:</label>
						   <div class="cell-right"><textarea name="js" class="textarea col-xs-4 col-lg-12 height200" id="js" ></textarea></div>  
					    </li>
					</ul>
					<div class="buttonstyle">
                    
						<a href="javascript:frm.submit()" title="保存添加" class="btn padding10 bg-deep-blue">发布商品</a>
						
					</div>
					
				</div>
				<div class="tab-conent prompt_style ">

				</div>
				<div class="tab-conent prompt_style ">

				</div>
			</div>
            </form>
		</div>
	</body>

</html>
<script>
	//内页框架
	$(function() {
		$("#pagestyle").Hupage({
			pagecontent:'.Bombbox-info',//自定义属性
			tabcontent:'.tabcontent',
			tabmemu:'.tab_memu',
			scrollbar: function(e) {
				e.niceScroll({
					cursorcolor: "#dddddd",
					cursoropacitymax: 1,
					touchbehavior: false,
					cursorwidth: "3px",
					cursorborder: "0",
					cursorborderradius: "3px",
				});
			},
			expand: function(thisBox, settings) {
				 $(settings.pagecontent).css({height:$(window).height()-30});
				settings.scrollbar($(settings.tabcontent).css({height:$(window).height()-$(settings.tabmemu).outerHeight()-30}));
			}
		})
	})
</script>
<?php

//如果标题不为空,说明其它的也不为空，所以处理
if (isset($_POST["bt"]))
{
	$bt=$_POST["bt"];
	$jg=$_POST["jg"];
	$js=$_POST["js"];
	if ($_FILES["tp"]["error"] >0) $tp="";
	else 
	{
		$tp=time().".".getKjm($_FILES["tp"]["name"]);
		move_uploaded_file($_FILES["tp"]["tmp_name"],"../upload/" . $tp);
	}

	$sql=sprintf("insert into cp(bt,jg,tp,js) values('%s',%u,'%s','%s')",$bt,$jg,$tp,$js);
	$cn->query($sql);
	$cn->close();
	 
	echo "<script>alert('发布成功！');</script>";
}

?>